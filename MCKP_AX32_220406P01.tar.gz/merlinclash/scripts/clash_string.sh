sed -i 's//\n/g' $1 


